<?php
/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

?>
			<footer id="site-footer" role="contentinfo" class="header-footer-group">
				 <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
             <?php dynamic_sidebar( 'sidebar-1' ); ?>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
           <?php dynamic_sidebar( 'sidebar-2' ); ?>
          </div>

        

          <div class="col-lg-6 col-md-12 footer-newsletter">
          	<h3 style="margin-top: 0px;">Follow us</h3>
              <ul id="footer-social">
		            <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
		            <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
		            <li><a href="#" target="_blank"><i class="fa fa-youtube"></i></a></li>
		        </ul>

          </div>
</div>
        </div>
      </div><!-- .section-inner -->

				<div class="row">
						<p class="copyright">&copy;
							<?php
							echo date_i18n(
								/* translators: Copyright date format, see https://www.php.net/manual/datetime.format.php */
								_x( 'Y', 'copyright date format', 'twentytwenty' )
							);
							?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
						</p><!-- .footer-copyright -->

						<p class="powered-by-wordpress">
							<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'twentytwenty' ) ); ?>">
								<?php _e( 'Powered by WordPress', 'twentytwenty' ); ?>
							</a>
						</p><!-- .powered-by-wordpress -->

					</div><!-- .footer-credits -->

					<a class="to-the-top" href="#site-header">
						<span class="to-the-top-long">
							<?php
							/* translators: %s: HTML character for up arrow. */
							printf( __( 'To the top %s', 'twentytwenty' ), '<span class="arrow" aria-hidden="true">&uarr;</span>' );
							?>
						</span><!-- .to-the-top-long -->
						<span class="to-the-top-short">
							<?php
							/* translators: %s: HTML character for up arrow. */
							printf( __( 'Up %s', 'twentytwenty' ), '<span class="arrow" aria-hidden="true">&uarr;</span>' );
							?>
						</span><!-- .to-the-top-short -->
					</a><!-- .to-the-top -->
</div>
				

				<script type="text/javascript">
					jQuery(document).ready(function(){
// 						jQuery('.box1').hover(function(){
// 							jQuery('.integrity').slideToggle('slow');
// 						});
// 						jQuery('.box2').hover(function(){
// 							jQuery('.Passion').slideToggle('slow');
// 						});
// 						jQuery('.box3').hover(function(){
// 							jQuery('.respect').slideToggle('slow');
// 						});
// 						jQuery('.box4').hover(function(){
// 							jQuery('.community').slideToggle('slow');
// 						});
						
						jQuery(window).scroll(function() {
							if (jQuery(this).scrollTop() > 1){ 
								jQuery('#topbar').addClass("topbar-scrolled");
								jQuery('header').addClass("sticky");
							}
							else{
								jQuery('#topbar').removeClass("topbar-scrolled");
								jQuery('header').removeClass("sticky");
							}
						});
					});
					AOS.init({
  duration: 1200,
});
				</script>

			</footer><!-- #site-footer -->

		<?php wp_footer(); ?>

	</body>
</html>
